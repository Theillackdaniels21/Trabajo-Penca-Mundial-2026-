import pandas as pd
import mysql.connector

# ==========================
# CONFIGURACIÓN
# ==========================

archivo = r"C:\Users\illan\Documents\Visual Studio Code\PencaMundial2026\excel\mundial2026_pencas_completada.xlsx"

conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="NuevaContraseña123",
    database="penca_mundial"
)

cursor = conexion.cursor()

# ==========================
# IMPORTAR SELECCIONES
# ==========================

selecciones = pd.read_excel(
    archivo,
    sheet_name="Selecciones",
    header=2
)

selecciones = selecciones.fillna("")

for _, fila in selecciones.iterrows():

    cursor.execute("""
        INSERT INTO selecciones
        (
            id_seleccion,
            pais,
            confederacion,
            entrenador,
            grupo,
            color
        )
        VALUES (%s,%s,%s,%s,%s,%s)
    """,
    (
        int(fila["ID_Selección"]),
        fila["País"],
        fila["Confederación"],
        fila["Entrenador"],
        fila["Grupo"],
        fila["Color "]
    ))

conexion.commit()

print("Selecciones importadas")

# ==========================
# IMPORTAR PARTIDOS
# ==========================

partidos = pd.read_excel(
    archivo,
    sheet_name="Partidos",
    header=2
)

for _, fila in partidos.iterrows():

    if pd.isna(fila["ID_Local"]) or pd.isna(fila["ID_Visitante"]):
        continue

    goles_local = None
    goles_visitante = None

    if not pd.isna(fila["Goles Local"]):
        goles_local = int(fila["Goles Local"])

    if not pd.isna(fila["Goles Visitante"]):
        goles_visitante = int(fila["Goles Visitante"])

    cursor.execute("""
        INSERT INTO partidos
        (
            id_partido,
            fecha,
            hora,
            sede,
            id_local,
            id_visitante,
            goles_local,
            goles_visitante,
            fase,
            estado
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """,
    (
        int(fila["ID_Partido"]),
        fila["Fecha"],
        fila["Hora (UYT)"],
        fila["Sede"],
        int(fila["ID_Local"]),
        int(fila["ID_Visitante"]),
        goles_local,
        goles_visitante,
        fila["Fase"],
        fila["Estado"]
    ))

conexion.commit()

print("Partidos importados")

# ==========================
# CERRAR CONEXIÓN
# ==========================

cursor.close()
conexion.close()

print("IMPORTACIÓN FINALIZADA")