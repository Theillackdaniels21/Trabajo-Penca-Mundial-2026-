DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = "NuevaContraseña123"
DB_NAME = "penca_mundial"