from flask import Flask, render_template, request, redirect, url_for, session
from utils.conexion import obtener_conexion

app = Flask(__name__)
app.secret_key = "penca2026"

@app.route("/")
def inicio():

    if "id_usuario" not in session:
        return redirect("/login")

    return render_template("index.html")

@app.route("/test-db")
def test_db():
    try:
        conexion = obtener_conexion()

        cursor = conexion.cursor()
        cursor.execute("SELECT DATABASE();")

        resultado = cursor.fetchone()

        cursor.close()
        conexion.close()

        return f"Conectado a la base: {resultado[0]}"

    except Exception as e:
        return f"Error de conexión: {e}"
    
@app.route("/usuarios")
def usuarios():

    if "id_usuario" not in session:
        return redirect("/login")

    if session["rol"] != "admin":
        return redirect("/")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            id_usuario,
            nombre,
            apellido,
            email,
            usuario,
            rol,
            puntos_totales
        FROM usuarios
    """)

    usuarios = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "usuarios.html",
        usuarios=usuarios
    )

@app.route("/login")
def login():

    if "id_usuario" in session:
        return redirect("/")

    return render_template("login.html")

@app.route("/login/verificar", methods=["POST"])
def verificar_login():

    usuario = request.form["usuario"]
    contrasena = request.form["contrasena"]

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            id_usuario,
            usuario,
            rol
        FROM usuarios
        WHERE usuario = %s
        AND contrasena_hash = %s
    """, (usuario, contrasena))

    resultado = cursor.fetchone()

    cursor.close()
    conexion.close()

    if resultado:

        session["id_usuario"] = resultado[0]
        session["usuario"] = resultado[1]
        session["rol"] = resultado[2]

        return redirect("/")

    return render_template(
        "login.html",
        error="Usuario o contraseña incorrectos"
    )

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/login")

@app.route("/registro")
def registro():

    if "id_usuario" in session:
        return redirect("/")

    return render_template("registro.html")


@app.route("/registro/guardar", methods=["POST"])
def guardar_registro():

    nombre = request.form["nombre"]
    apellido = request.form["apellido"]
    email = request.form["email"]
    usuario = request.form["usuario"]
    contrasena = request.form["contrasena"]

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        INSERT INTO usuarios
        (
            nombre,
            apellido,
            email,
            usuario,
            contrasena_hash,
            fecha_registro,
            rol,
            estado,
            puntos_totales
        )
        VALUES
        (
            %s,%s,%s,%s,%s,
            CURDATE(),
            'usuario',
            'Activo',
            0
        )
    """, (
        nombre,
        apellido,
        email,
        usuario,
        contrasena
    ))

    conexion.commit()

    cursor.close()
    conexion.close()

    return redirect("/login")

@app.route("/partidos")
def partidos():

    if "id_usuario" not in session:
        return redirect("/login")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            p.id_partido,
            p.fecha,
            p.hora,
            sl.pais,
            sv.pais,
            p.fase,
            p.estado
        FROM partidos p
        INNER JOIN selecciones sl
            ON p.id_local = sl.id_seleccion
        INNER JOIN selecciones sv
            ON p.id_visitante = sv.id_seleccion
        ORDER BY p.fecha, p.hora
    """)

    partidos = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "partidos.html",
        partidos=partidos
    )

@app.route("/pronosticos")
def pronosticos():

    if "id_usuario" not in session:
        return redirect("/login")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            p.id_partido,
            sl.pais,
            sv.pais
        FROM partidos p
        INNER JOIN selecciones sl
            ON p.id_local = sl.id_seleccion
        INNER JOIN selecciones sv
            ON p.id_visitante = sv.id_seleccion
        ORDER BY p.fecha, p.hora
    """)

    partidos = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "pronosticos.html",
        partidos=partidos
    )

@app.route("/pronosticos/guardar", methods=["POST"])
def guardar_pronostico():

    if "id_usuario" not in session:
        return redirect("/login")

    id_usuario = session["id_usuario"]
    id_partido = request.form["id_partido"]
    pred_local = request.form["pred_local"]
    pred_visitante = request.form["pred_visitante"]

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT id_pronostico
        FROM pronosticos
        WHERE id_usuario = %s
        AND id_partido = %s
    """, (
        id_usuario,
        id_partido
    ))

    existe = cursor.fetchone()

    if existe:

        cursor.execute("""
            UPDATE pronosticos
            SET
                pred_local = %s,
                pred_visitante = %s
            WHERE id_usuario = %s
            AND id_partido = %s
        """, (
            pred_local,
            pred_visitante,
            id_usuario,
            id_partido
        ))

    else:

        cursor.execute("""
            INSERT INTO pronosticos
            (
                id_usuario,
                id_partido,
                pred_local,
                pred_visitante
            )
            VALUES (%s,%s,%s,%s)
        """, (
            id_usuario,
            id_partido,
            pred_local,
            pred_visitante
        ))

    conexion.commit()

    cursor.close()
    conexion.close()

    return redirect("/pronosticos")

@app.route("/resultados")
def resultados():

    if "id_usuario" not in session:
        return redirect("/login")

    if session["rol"] != "admin":
        return redirect("/")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            p.id_partido,
            sl.pais,
            sv.pais,
            p.goles_local,
            p.goles_visitante
        FROM partidos p
        INNER JOIN selecciones sl
            ON p.id_local = sl.id_seleccion
        INNER JOIN selecciones sv
            ON p.id_visitante = sv.id_seleccion
        ORDER BY p.fecha, p.hora
    """)

    partidos = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "resultados.html",
        partidos=partidos
    )

@app.route("/resultados/guardar", methods=["POST"])
def guardar_resultado():

    if "id_usuario" not in session:
        return redirect("/login")

    if session["rol"] != "admin":
        return redirect("/")

    id_partido = request.form["id_partido"]
    goles_local = request.form["goles_local"]
    goles_visitante = request.form["goles_visitante"]

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        UPDATE partidos
        SET
            goles_local = %s,
            goles_visitante = %s
        WHERE id_partido = %s
    """, (
        goles_local,
        goles_visitante,
        id_partido
    ))

    conexion.commit()

    cursor.close()
    conexion.close()

    return redirect("/resultados")

@app.route("/calcular_puntos")
def calcular_puntos():

    if "id_usuario" not in session:
        return redirect("/login")

    if session["rol"] != "admin":
        return redirect("/")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            pr.id_pronostico,
            pr.pred_local,
            pr.pred_visitante,
            pa.goles_local,
            pa.goles_visitante
        FROM pronosticos pr
        INNER JOIN partidos pa
            ON pr.id_partido = pa.id_partido
        WHERE pa.goles_local IS NOT NULL
        AND pa.goles_visitante IS NOT NULL
    """)

    datos = cursor.fetchall()

    for fila in datos:

        id_pronostico = fila[0]

        pred_local = fila[1]
        pred_visitante = fila[2]

        goles_local = fila[3]
        goles_visitante = fila[4]

        puntos = 0

        # Resultado exacto

        if (
            pred_local == goles_local
            and
            pred_visitante == goles_visitante
        ):
            puntos = 5

        else:

            # Ganador pronosticado

            if pred_local > pred_visitante:
                resultado_pronostico = "L"

            elif pred_local < pred_visitante:
                resultado_pronostico = "V"

            else:
                resultado_pronostico = "E"

            # Ganador real

            if goles_local > goles_visitante:
                resultado_real = "L"

            elif goles_local < goles_visitante:
                resultado_real = "V"

            else:
                resultado_real = "E"

            if resultado_pronostico == resultado_real:
                puntos = 3

        cursor.execute("""
            UPDATE pronosticos
            SET puntos = %s
            WHERE id_pronostico = %s
        """, (
            puntos,
            id_pronostico
        ))

    conexion.commit()

    cursor.execute("""
        UPDATE usuarios
        SET puntos_totales = 0
    """)

    cursor.execute("""
        SELECT
            id_usuario,
            SUM(puntos)
        FROM pronosticos
        GROUP BY id_usuario
    """)

    totales = cursor.fetchall()

    for fila in totales:

        id_usuario = fila[0]
        puntos = fila[1]

        cursor.execute("""
            UPDATE usuarios
            SET puntos_totales = %s
            WHERE id_usuario = %s
        """, (
            puntos,
            id_usuario
        ))

    conexion.commit()

    cursor.close()
    conexion.close()

    return redirect("/")

@app.route("/ranking")
def ranking():

    if "id_usuario" not in session:
        return redirect("/login")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            usuario,
            puntos_totales
        FROM usuarios
        ORDER BY puntos_totales DESC, usuario ASC
    """)

    ranking = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "ranking.html",
        ranking=ranking
    )

@app.route("/selecciones")
def selecciones():

    if "id_usuario" not in session:
        return redirect("/login")

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT
            pais,
            confederacion,
            entrenador,
            grupo,
            color
        FROM selecciones
        ORDER BY grupo, pais
    """)

    selecciones = cursor.fetchall()

    cursor.close()
    conexion.close()

    return render_template(
        "selecciones.html",
        selecciones=selecciones
    )

if __name__ == "__main__":
    app.run(debug=True)